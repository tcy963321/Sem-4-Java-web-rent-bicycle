-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 25, 2020 at 05:56 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rentbicycle`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Adminid` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `IC` varchar(255) NOT NULL,
  `Contact_number` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Username` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Adminid`, `Name`, `IC`, `Contact_number`, `Email`, `Username`, `Password`) VALUES
(1, 'TANG CHOON YEW', '960729-08-5853', '0165385048', 'tangmax01@gmail.com', 'Admin', '1'),
(4, 'Chua ZIWAN', '980102085859', '3265412', 'ZiWan@gmail.com', 'ziwan', '123');

-- --------------------------------------------------------

--
-- Table structure for table `bicycle`
--

CREATE TABLE `bicycle` (
  `Bicycle_ID` varchar(255) NOT NULL,
  `Bicycle_Model` varchar(255) NOT NULL,
  `Features` varchar(500) NOT NULL,
  `Stock` varchar(255) NOT NULL,
  `Rental_Price` varchar(11) NOT NULL DEFAULT '6',
  `Status` varchar(255) NOT NULL,
  `Filename` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bicycle`
--

INSERT INTO `bicycle` (`Bicycle_ID`, `Bicycle_Model`, `Features`, `Stock`, `Rental_Price`, `Status`, `Filename`) VALUES
('J1', 'Jordan', 'FAST STABLE Safe', '10', '6.00', 'NO AVAILABLE', 'images\\WhatsApp Image 2020-05-04 at 7.44.53 PM (7).jpeg'),
('S1', 'SSS', 'Fast', '10', '6.00', 'Not Available', 'images\\WhatsApp Image 2020-05-04 at 7.44.53 PM (2).jpeg'),
('S100', 'EY', 'Fast', '5', '6.00', 'Available', 'images\\WhatsApp Image 2020-05-04 at 7.44.53 PM (1).jpeg'),
('S3', 'sad', 'slow', '10', '6.00', 'Available', 'images\\WhatsApp Image 2020-05-04 at 7.44.53 PM (5).jpeg'),
('S50', '5050', 'Fast many color', '10', '6.00', 'Available', 'images\\WhatsApp Image 2020-05-04 at 7.44.53 PM (4).jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `BookingID` int(11) NOT NULL,
  `CustomerName` varchar(255) NOT NULL,
  `Contact_Number` varchar(255) DEFAULT NULL,
  `Customer_ID` int(11) NOT NULL,
  `Bicycle_ID` varchar(255) DEFAULT NULL,
  `Quantity` int(11) NOT NULL,
  `Rental_Date` varchar(255) DEFAULT NULL,
  `Return_Date` varchar(255) DEFAULT NULL,
  `Rental_Type` varchar(255) DEFAULT NULL,
  `Rental_Fees` varchar(20) DEFAULT NULL,
  `Payment` varchar(255) NOT NULL DEFAULT 'Unpaid',
  `Status` varchar(255) NOT NULL DEFAULT 'Waiting',
  `Receipt` varchar(255) NOT NULL DEFAULT 'Not yet Upload Receipt'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Customer_ID` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `IC` varchar(255) DEFAULT NULL,
  `Contact_number` varchar(255) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Username` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`Customer_ID`, `Name`, `IC`, `Contact_number`, `Address`, `Email`, `Username`, `Password`) VALUES
(1, 'Tang Choon Yew', '960729085853', '0165385048', 'PT13716,TMN MASAMAH', 'tangmax0153@gmail.com', 'tcy', '123**'),
(5, 'Zehel', '5215212512512', '0165385048', 'Universiti Malaysia Terengganu, 21300 Kuala Terengganu, Terengganu', 'dr@gmail.com', '1234', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `PaymentID` int(11) NOT NULL,
  `Receipt` varchar(255) NOT NULL,
  `BookingID` int(11) NOT NULL,
  `Status` varchar(255) NOT NULL DEFAULT 'Unreceived',
  `Check_Date` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `Staffid` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `IC` varchar(255) NOT NULL,
  `Address` varchar(255) NOT NULL,
  `Contact_number` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Username` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Position` varchar(255) DEFAULT NULL,
  `Validation` varchar(255) NOT NULL DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`Staffid`, `Name`, `IC`, `Address`, `Contact_number`, `Email`, `Username`, `Password`, `Position`, `Validation`) VALUES
(1, 'Fk', '980222-02-5356', '0135947786', 'PT13716,TMN MASAMAH', 'fk123@gmail.com', 'FK', '123**', 'Manager', 'Approved'),
(2, 'jordan', '45256215632', '0165385048', 'Universiti Malaysia Terengganu, 21300 Kuala Terengganu, Terengganu', 'tangmax01@gmail.com', 'jor', 'dan', 'Sales Executive', 'Approved');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Adminid`);

--
-- Indexes for table `bicycle`
--
ALTER TABLE `bicycle`
  ADD PRIMARY KEY (`Bicycle_ID`);

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`BookingID`),
  ADD KEY `Customer_ID` (`Customer_ID`),
  ADD KEY `ADD FOREIGN` (`Bicycle_ID`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Customer_ID`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`PaymentID`),
  ADD KEY `BookingID` (`BookingID`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`Staffid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `Adminid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `BookingID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10015;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `Customer_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `PaymentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10008;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `Staffid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `booking`
--
ALTER TABLE `booking`
  ADD CONSTRAINT `ADD FOREIGN` FOREIGN KEY (`Bicycle_ID`) REFERENCES `bicycle` (`Bicycle_ID`) ON DELETE SET NULL ON UPDATE SET NULL,
  ADD CONSTRAINT `booking_ibfk_1` FOREIGN KEY (`Customer_ID`) REFERENCES `customer` (`Customer_ID`);

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`BookingID`) REFERENCES `booking` (`BookingID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
