/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

/**
 *
 * @author User
 */
public class DeleteDao {
    
     public static Connection getConnection(){
        Connection con = null;
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rentbicycle","root", "");
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return con;
    }
    
    public static int deleteCust(int id){
    int status =0;
    try{
    Connection con=DeleteDao.getConnection();
    PreparedStatement ps=con.prepareStatement("delete from customer where Customerid=?");
    ps.setInt(1,id);
    
    status=ps.executeUpdate();
    
    con.close();
    } catch (Exception ex){
    ex.printStackTrace();
    }
    return status;
    }
    
    public static int deleteStaff(int id){
    int status =0;
    try{
    Connection con=DeleteDao.getConnection();
    PreparedStatement ps=con.prepareStatement("delete from staff where Staffid=?");
    ps.setInt(1,id);
    
    status=ps.executeUpdate();
    
    con.close();
    } catch (Exception ex){
    ex.printStackTrace();
    }
    return status;
    }
    
    public static int deleteAdmin(int id){
    int status =0;
    try{
    Connection con=DeleteDao.getConnection();
    PreparedStatement ps=con.prepareStatement("delete from admin where Adminid=?");
    ps.setInt(1,id);
    
    status=ps.executeUpdate();
    
    con.close();
    } catch (Exception ex){
    ex.printStackTrace();
    }
    return status;
    }
    
    
}
