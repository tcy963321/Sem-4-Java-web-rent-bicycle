package com;


import com.Staff;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class DaoLogin {
    
    public static Connection getConnection(){
        Connection con = null;
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rentbicycle","root", "");
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return con;
    }
    
    public static boolean validatestaff(String un, String pass){
        boolean status = false;
        try{
            Connection con = DaoLogin.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from staff where Username=? and Password=?");
            ps.setString(1, un);
            ps.setString(2, pass);
            
            ResultSet rs = ps.executeQuery();
            status = rs.next();
        }
        catch(Exception ex){
            ex.printStackTrace();
        }
        return status;
    }
    
    public static Staff getValidateKey(String un){
       Staff s = new Staff();
        try{
            Connection con = DaoLogin.getConnection();
            PreparedStatement ps = con.prepareStatement("select Validation from staff where Username=?");
            
            ps.setString(1, un);
            ResultSet rs = ps.executeQuery();
            
            if(rs.next()){
                s.setValidation(rs.getString("validation"));
            }
            con.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return s;
    }
     public static boolean validateCust(String un, String pass){
        boolean status = false;
        try{
            Connection con = DaoLogin.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from customer where Username=? and Password=?");
            ps.setString(1, un);
            ps.setString(2, pass);
            
            ResultSet rs = ps.executeQuery();
            status = rs.next();
        }
        catch(Exception ex){
            ex.printStackTrace();
        }
        return status;
    }
    
    public static boolean validateAd(String un, String pass){
        boolean status = false;
        try{
            Connection con = DaoLogin.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from admin where Username=? and Password=?");
            ps.setString(1, un);
            ps.setString(2, pass);
            
            ResultSet rs = ps.executeQuery();
            status = rs.next();
        }
        catch(Exception ex){
            ex.printStackTrace();
        }
        return status;
    }
}

