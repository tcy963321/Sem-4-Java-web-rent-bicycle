/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author User
 */
public class ViewBicycledao {
 
      public static Connection getConnection(){
    Connection con=null;
    try{
    Class.forName("com.mysql.jdbc.Driver");
    con=DriverManager.getConnection("jdbc:mysql://localhost:3306/rentbicycle","root","");
    }
    catch (Exception e){
    System.out.println(e);
    }
    return con;
    }
    
    public static  Bicycle getBicById(String id){
    Bicycle e= new  Bicycle();
    try{
    Connection con=ViewDao.getConnection();
    PreparedStatement ps=con.prepareStatement("select*from bicycle where Bicycle_ID=?");
    ps.setString(1,id);
    ResultSet rs= ps.executeQuery();
    
    if(rs.next())
    {
    e.setBicycle_ID(rs.getString(1));
    e.setBicycle_Model(rs.getString(2));
    e.setFeatures(rs.getString(3));
    e.setStock(rs.getString(4));
    e.setPrice(rs.getString(5));
    e.setStatus(rs.getString(6));
    e.setFilename(rs.getString(7));
   // e.setPath(rs.getString(7));
    }
   
    con.close();
    } catch (Exception ex){
    ex.printStackTrace();
    }
    return e;
    }
    
    
    public static int updatestaffbic(Bicycle e){
    int status =0;
    try{
    Connection con=UpdateDao.getConnection();
    PreparedStatement ps=con.prepareStatement("update bicycle set Bicycle_Model=?,Features=?,Stock=?,Rental_Price=?,Status=? where Bicycle_ID=?");
    ps.setString(1,e.getBicycle_Model());
    ps.setString(2,e.getFeatures());
    ps.setString(3,e.getStock());
    ps.setString(4,e.getPrice());
    ps.setString(5,e.getStatus());
    ps.setString(6,e.getBicycle_ID());
    
    status=ps.executeUpdate();
    
    con.close();
    } catch (Exception ex){
    ex.printStackTrace();
    }
    return status;
    }
    
    public static int Bookingsave(Booking appoint){
        int status = 0;
        try{
            Connection con = ViewBicycledao.getConnection();
            PreparedStatement ps = con.prepareStatement("insert into booking(CustomerName,Contact_Number,Customer_ID,Bicycle_ID,Quantity,Rental_Date,Return_Date,Rental_Type,Rental_Fees) values(?,?,?,?,?,?,?,?,?)");
           
            ps.setString(1, appoint.getCNAME());
            ps.setString(2, appoint.getCN());
            ps.setInt(3, appoint.getCID());
            ps.setString(4, appoint.getBID()); 
            ps.setInt(5, appoint.getQuantity()); 
            ps.setString(6, appoint.getRental());
            ps.setString(7, appoint.getReturn());     
            ps.setString(8, appoint.getRtype());      
            ps.setDouble(9, appoint.getPrice());         
            status = ps.executeUpdate();
            
            con.close();
        }
        catch(Exception ex){
            ex.printStackTrace();
        }
        return status;
    }
    
    public static List<Booking> viewbook(String id){
    List<Booking> list =new ArrayList<Booking>();
    try{
    Connection con = ViewBicycledao.getConnection();
    PreparedStatement ps=con.prepareStatement("select*from booking where Customer_ID=? and Status='Waiting' and Payment='Unpaid' ");
    ps.setString(1,id);
    ResultSet rs= ps.executeQuery();
    
     while (rs.next())
    {
    Booking e=new Booking();
     e.setBOOKINGID(rs.getInt(1));
    e.setCNAME(rs.getString(2));
    e.setCN(rs.getString(3));
    e.setCID(rs.getInt(4));
    e.setBID(rs.getString(5));
    e.setQuantity(rs.getInt(6));
    e.setRental(rs.getString(7));
    e.setReturn(rs.getString(8));
    e.setRtype(rs.getString(9));
    e.setPrice(rs.getDouble(10));
    e.setPayment(rs.getString(11));
    e.setStatus(rs.getString(12));
    e.setReceipt(rs.getString(13));
    list.add(e);
    }
    con.close();
    } catch (Exception ex){
    ex.printStackTrace();
    }
    return list;
    }
    
    public static int custcancel (int id){
    int status =0;
    try{
    Connection con = ViewBicycledao.getConnection();
    PreparedStatement ps=con.prepareStatement("delete from booking where BookingID=?");
    ps.setInt(1,id);
    
    status=ps.executeUpdate();
    
    con.close();
    } catch (Exception ex){
    ex.printStackTrace();
    }
    return status;
    }
    
    public static  Booking getBookById(int id){
    Booking e= new  Booking();
    try{
    Connection con=ViewDao.getConnection();
    PreparedStatement ps=con.prepareStatement("select*from booking where BookingID=?");
    ps.setInt(1,id);
    ResultSet rs= ps.executeQuery();
    
    if(rs.next())
    {
    e.setBOOKINGID(rs.getInt(1));
    e.setCNAME(rs.getString(2));
    e.setCN(rs.getString(3));
    e.setCID(rs.getInt(4));
    e.setBID(rs.getString(5));
    e.setQuantity(rs.getInt(6));
    e.setRental(rs.getString(7));
    e.setReturn(rs.getString(8));
    e.setRtype(rs.getString(9));
    e.setPrice(rs.getDouble(10));
    e.setPayment(rs.getString(11));
    e.setStatus(rs.getString(12));
    e.setReceipt(rs.getString(13));
    }
   
    con.close();
    } catch (Exception ex){
    ex.printStackTrace();
    }
    return e;
    }
    
     public static List<Booking> getALLBooking()
    {
    
    List<Booking> list =new ArrayList<Booking>();
    
    try{
    Connection con=ViewBicycledao.getConnection();
    PreparedStatement ps=con.prepareStatement("select*from booking where Payment='Unpaid' and Status='Waiting' Order By BookingID Desc");
    ResultSet rs= ps.executeQuery();
     while (rs.next())
     {
     Booking e=new Booking();
    e.setBOOKINGID(rs.getInt(1));
    e.setCNAME(rs.getString(2));
    e.setCN(rs.getString(3));
    e.setCID(rs.getInt(4));
    e.setBID(rs.getString(5));
    e.setQuantity(rs.getInt(6));
    e.setRental(rs.getString(7));
    e.setReturn(rs.getString(8));
    e.setRtype(rs.getString(9));
    e.setPrice(rs.getDouble(10));
    e.setPayment(rs.getString(11));
    e.setStatus(rs.getString(12));
    e.setReceipt(rs.getString(13));
    list.add(e);
     }
      con.close();
    } catch (Exception ex){
    ex.printStackTrace();
    }
    return list;
    }
     
     public static List<Payment> getALLPayment()
    {
    
    List<Payment> list =new ArrayList<Payment>();
    
    try{
    Connection con=ViewBicycledao.getConnection();
    PreparedStatement ps=con.prepareStatement("select*from Payment where Status='Unreceived' Order By PaymentID Desc");
    ResultSet rs= ps.executeQuery();
     while (rs.next())
     {
     Payment e=new Payment();
      e.setPaymentid(rs.getInt(1));
      e.setReceipt(rs.getString(2));
    e.setBookingid(rs.getInt(3));
    e.setStatus(rs.getString(4));
    
    list.add(e);
     }
      con.close();
    } catch (Exception ex){
    ex.printStackTrace();
    }
    return list;
    } 
     
    public static  Payment getPaymentById(int id){
    Payment e= new  Payment();
    try{
    Connection con=ViewDao.getConnection();
    PreparedStatement ps=con.prepareStatement("select*from payment where PaymentID=?");
    ps.setInt(1,id);
    ResultSet rs= ps.executeQuery();
    
    if(rs.next())
    {
    e.setPaymentid(rs.getInt(1));
    e.setReceipt(rs.getString(2));
    e.setBookingid(rs.getInt(3));
    e.setStatus(rs.getString(4));
    e.setCheckdate(rs.getString(5));
    }
   
    con.close();
    } catch (Exception ex){
    ex.printStackTrace();
    }
    return e;
    }
    
    public static int updateCustbooking(Booking e){
    int status =0;
    try{
    Connection con=UpdateDao.getConnection();
    PreparedStatement ps=con.prepareStatement("update booking set CustomerName=?,Contact_Number=?,Customer_ID=?,Bicycle_ID=?,Quantity=?,Rental_Date=?,Return_Date=?,Rental_Type=?,Rental_Fees=?,Payment=?,Status=?,Receipt=? where BookingID=?");
    ps.setString(1,e.getCNAME());
    ps.setString(2,e.getCN());
    ps.setInt(3,e.getCID());
    ps.setString(4,e.getBID());
    ps.setInt(5,e.getQuantity());
    ps.setString(6,e.getRental());
    ps.setString(7,e.getReturn());
    ps.setString(8,e.getRtype());
    ps.setDouble(9,e.getPrice());
    ps.setString(10,e.getPayment());
    ps.setString(11,e.getStatus());
    ps.setString(12,e.getReceipt());
    ps.setInt(13,e.getBOOKINGID());
    
    status=ps.executeUpdate();
    
    con.close();
    } catch (Exception ex){
    ex.printStackTrace();
    }
    return status;
    }
    
    public static int StaffupdatePaid(Payment e){
    int status =0;
    try{
    Connection con=UpdateDao.getConnection();
    PreparedStatement ps=con.prepareStatement("update payment set BookingID=?,Status=?,Check_Date=? where PaymentID=?");
    ps.setInt(1,e.getBookingid());
    ps.setString(2,e.getStatus());
    ps.setString(3,e.getCheckdate());
    ps.setInt(4,e.getPaymentid());
    status=ps.executeUpdate();
    
    con.close();
    } catch (Exception ex){
    ex.printStackTrace();
    }
    return status;
    }
    
   public static List<Booking> viewstaffbookhistory(){
    List<Booking> list =new ArrayList<Booking>();
    try{
    Connection con = ViewBicycledao.getConnection();
    PreparedStatement ps=con.prepareStatement("select*from booking where Status='Approved' and Payment='Paid' Order By BookingID DESC ");
    ResultSet rs= ps.executeQuery();
    
     while (rs.next())
    {
    Booking e=new Booking();
    e.setBOOKINGID(rs.getInt(1));
    e.setCNAME(rs.getString(2));
    e.setCN(rs.getString(3));
    e.setCID(rs.getInt(4));
    e.setBID(rs.getString(5));
    e.setQuantity(rs.getInt(6));
    e.setRental(rs.getString(7));
    e.setReturn(rs.getString(8));
    e.setRtype(rs.getString(9));
    e.setPrice(rs.getDouble(10));
    e.setPayment(rs.getString(11));
    e.setStatus(rs.getString(12));
    e.setReceipt(rs.getString(13));
    list.add(e);
    }
    con.close();
    } catch (Exception ex){
    ex.printStackTrace();
    }
    return list;
    }
   
    public static List<Payment> getALLPaymentHistory()
    {
    
    List<Payment> list =new ArrayList<Payment>();
    
    try{
    Connection con=ViewBicycledao.getConnection();
    PreparedStatement ps=con.prepareStatement("select*from Payment where Status='Received' Order By PaymentID Desc ");
    ResultSet rs= ps.executeQuery();
     while (rs.next())
     {
     Payment e=new Payment();
      e.setPaymentid(rs.getInt(1));
      e.setReceipt(rs.getString(2));
    e.setBookingid(rs.getInt(3));
    e.setStatus(rs.getString(4));
    
    list.add(e);
     }
      con.close();
    } catch (Exception ex){
    ex.printStackTrace();
    }
    return list;
    } 
    
    public static List<Booking> custviewbook(String id){
    List<Booking> list =new ArrayList<Booking>();
    try{
    Connection con = ViewBicycledao.getConnection();
    PreparedStatement ps=con.prepareStatement("select*from booking where Customer_ID=? and Status='Approved' and Payment='Paid' Order By BookingID Desc ");
    ps.setString(1,id);
    ResultSet rs= ps.executeQuery();
    
     while (rs.next())
    {
    Booking e=new Booking();
    e.setBOOKINGID(rs.getInt(1));
    e.setCNAME(rs.getString(2));
    e.setCN(rs.getString(3));
    e.setCID(rs.getInt(4));
    e.setBID(rs.getString(5));
    e.setQuantity(rs.getInt(6));
    e.setRental(rs.getString(7));
    e.setReturn(rs.getString(8));
    e.setRtype(rs.getString(9));
    e.setPrice(rs.getDouble(10));
    e.setPayment(rs.getString(11));
    e.setStatus(rs.getString(12));
    e.setReceipt(rs.getString(13));
    list.add(e);
    }
    con.close();
    } catch (Exception ex){
    ex.printStackTrace();
    }
    return list;
    }
    
    public static int AdmindeleteBic (String id){
    int status =0;
    try{
    Connection con = ViewBicycledao.getConnection();
    PreparedStatement ps=con.prepareStatement("delete from bicycle where Bicycle_ID=?");
    ps.setString(1,id);
    
    status=ps.executeUpdate();
    
    con.close();
    } catch (Exception ex){
    ex.printStackTrace();
    }
    return status;
    }
    
    public static int StaffdeleteBic (String id){
    int status =0;
    try{
    Connection con = ViewBicycledao.getConnection();
    PreparedStatement ps=con.prepareStatement("delete from bicycle where Bicycle_ID=?");
    ps.setString(1,id);
    
    status=ps.executeUpdate();
    
    con.close();
    } catch (Exception ex){
    ex.printStackTrace();
    }
    return status;
    }
    
    public static int AdmindeletePayment (int id){
    int status =0;
    try{
    Connection con = ViewBicycledao.getConnection();
    PreparedStatement ps=con.prepareStatement("delete from payment where PaymentID=?");
    ps.setInt(1,id);
    
    status=ps.executeUpdate();
    
    con.close();
    } catch (Exception ex){
    ex.printStackTrace();
    }
    return status;
    }
    
             public static int AdmindeleteBooking (int id){
    int status =0;
    try{
    Connection con = ViewBicycledao.getConnection();
    PreparedStatement ps=con.prepareStatement("delete from booking where BookingID=?");
    ps.setInt(1,id);
    
    status=ps.executeUpdate();
    
    con.close();
    } catch (Exception ex){
    ex.printStackTrace();
    }
    return status;
    }
}
