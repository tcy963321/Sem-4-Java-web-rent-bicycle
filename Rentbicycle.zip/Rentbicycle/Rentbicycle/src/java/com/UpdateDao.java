/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

/**
 *
 * @author User
 */
public class UpdateDao {
     public static Connection getConnection(){
    Connection con=null;
    try{
    Class.forName("com.mysql.jdbc.Driver");
    con=DriverManager.getConnection("jdbc:mysql://localhost:3306/rentbicycle","root","");
    }
    catch (Exception e){
    System.out.println(e);
    }
    return con;
    }
     
    public static int updateCust(Customer e){
    int status =0;
    try{
    Connection con=UpdateDao.getConnection();
    PreparedStatement ps=con.prepareStatement("update customer set Name=?,IC=?,Contact_number=?,Address=?,Email=?,Username=?,Password=? where Customerid=?");
    ps.setString(1,e.getName());
    ps.setString(2,e.getIc());
    ps.setString(3,e.getPhone_num());
    ps.setString(4,e.getAddress());
    ps.setString(5,e.getEmail());
    ps.setString(6,e.getUsername());
    ps.setString(7,e.getPassword());
    ps.setInt(8,e.getId());
    
    status=ps.executeUpdate();
    
    con.close();
    } catch (Exception ex){
    ex.printStackTrace();
    }
    return status;
    }
  
    public static int updateStaff(Staff e){
    int status =0;
    try{
    Connection con=UpdateDao.getConnection();
    PreparedStatement ps=con.prepareStatement("update staff set Name=?,IC=?,Contact_number=?,Address=?,Email=?,Username=?,Password=? where Staffid=?");
    ps.setString(1,e.getName());
    ps.setString(2,e.getIc());
    ps.setString(3,e.getPhone_num());
    ps.setString(4,e.getAddress());
    ps.setString(5,e.getEmail());
    ps.setString(6,e.getUsername());
    ps.setString(7,e.getPassword());
    ps.setInt(8,e.getId());
    
    status=ps.executeUpdate();
    
    con.close();
    } catch (Exception ex){
    ex.printStackTrace();
    }
    return status;
    }
    
    public static int updateAdmin(Admin e){
    int status =0;
    try{
    Connection con=UpdateDao.getConnection();
    PreparedStatement ps=con.prepareStatement("update admin set Name=?,IC=?,Contact_number=?,Email=?,Username=?,Password=? where Adminid=?");
    ps.setString(1,e.getName());
    ps.setString(2,e.getIc());
    ps.setString(3,e.getPhone_num());
    ps.setString(4,e.getEmail());
    ps.setString(5,e.getUsername());
    ps.setString(6,e.getPassword());
    ps.setInt(7,e.getId());
    
    status=ps.executeUpdate();
    
    con.close();
    } catch (Exception ex){
    ex.printStackTrace();
    }
    return status;
    }
    
    public static int AdminupdateStaff(Staff e){
    int status =0;
    try{
    Connection con=UpdateDao.getConnection();
    PreparedStatement ps=con.prepareStatement("update staff set Name=?,IC=?,Contact_number=?,Address=?,Email=?,Username=?,Password=?,Position=?,Validation=? where Staffid=?");
    ps.setString(1,e.getName());
    ps.setString(2,e.getIc());
    ps.setString(3,e.getPhone_num());
    ps.setString(4,e.getAddress());
    ps.setString(5,e.getEmail());
    ps.setString(6,e.getUsername());
    ps.setString(7,e.getPassword());
    ps.setString(8,e.getPosition());
    ps.setString(9,e.getValidation());
    ps.setInt(10,e.getId());
    
    status=ps.executeUpdate();
    
    con.close();
    } catch (Exception ex){
    ex.printStackTrace();
    }
    return status;
    }
    
}
