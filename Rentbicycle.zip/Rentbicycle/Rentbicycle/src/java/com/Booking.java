/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

/**
 *
 * @author User
 */
public class Booking {
    private String CNAME,CN,BID,Rental,Return,Rtype,Payment,Status,Receipt,State;
    private int BOOKINGID,CID,Quantity;
private double Price;

    public String getState() {
        return State;
    }

    public void setState(String State) {
        this.State = State;
    }

    public double getPrice() {
        return Price;
    }

    public void setPrice(double Price) {
        this.Price = Price;
    }

    public int getQuantity() {
        return Quantity;
    }

    public void setQuantity(int Quantity) {
        this.Quantity = Quantity;
    }
    public String getPayment() {
        return Payment;
    }

    public void setPayment(String Payment) {
        this.Payment = Payment;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String Status) {
        this.Status = Status;
    }

    public String getReceipt() {
        return Receipt;
    }

    public void setReceipt(String Receipt) {
        this.Receipt = Receipt;
    }
    

    public int getBOOKINGID() {
        return BOOKINGID;
    }

    public void setBOOKINGID(int BOOKINGID) {
        this.BOOKINGID = BOOKINGID;
    }

    public int getCID() {
        return CID;
    }

    public void setCID(int CID) {
        this.CID = CID;
    }

    public String getCNAME() {
        return CNAME;
    }

    public void setCNAME(String CNAME) {
        this.CNAME = CNAME;
    }

    public String getCN() {
        return CN;
    }

    public void setCN(String CN) {
        this.CN = CN;
    }

    public String getBID() {
        return BID;
    }

    public void setBID(String BID) {
        this.BID = BID;
    }

    public String getRental() {
        return Rental;
    }

    public void setRental(String Rental) {
        this.Rental = Rental;
    }

    public String getReturn() {
        return Return;
    }

    public void setReturn(String Return) {
        this.Return = Return;
    }

    public String getRtype() {
        return Rtype;
    }

    public void setRtype(String Rtype) {
        this.Rtype = Rtype;
    }
}
