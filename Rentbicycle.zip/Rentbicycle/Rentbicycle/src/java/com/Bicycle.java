/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

/**
 *
 * @author User
 */
public class Bicycle {
    private String Bicycle_ID,Bicycle_Model,Features,Stock,Status,Filename,path,price;

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getBicycle_ID() {
        return Bicycle_ID;
    }

    public void setBicycle_ID(String Bicycle_ID) {
        this.Bicycle_ID = Bicycle_ID;
    }

    public String getBicycle_Model() {
        return Bicycle_Model;
    }

    public void setBicycle_Model(String Bicycle_Model) {
        this.Bicycle_Model = Bicycle_Model;
    }

    public String getFeatures() {
        return Features;
    }

    public void setFeatures(String Features) {
        this.Features = Features;
    }

    public String getStock() {
        return Stock;
    }

    public void setStock(String Stock) {
        this.Stock = Stock;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String Status) {
        this.Status = Status;
    }

    public String getFilename() {
        return Filename;
    }

    public void setFilename(String Filename) {
        this.Filename = Filename;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }
}
