/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

/**
 *
 * @author User
 */
public class Payment {
    
    int Paymentid,Bookingid;
    String Receipt,Status,Checkdate;

    public int getPaymentid() {
        return Paymentid;
    }

    public void setPaymentid(int Paymentid) {
        this.Paymentid = Paymentid;
    }

    public int getBookingid() {
        return Bookingid;
    }

    public void setBookingid(int Bookingid) {
        this.Bookingid = Bookingid;
    }

    public String getReceipt() {
        return Receipt;
    }

    public void setReceipt(String Receipt) {
        this.Receipt = Receipt;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String Status) {
        this.Status = Status;
    }
    

    public String getCheckdate() {
        return Checkdate;
    }

    public void setCheckdate(String Checkdate) {
        this.Checkdate = Checkdate;
    }
}
