/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author User
 */
public class ViewDao {
     public static Connection getConnection(){
    Connection con=null;
    try{
    Class.forName("com.mysql.jdbc.Driver");
    con=DriverManager.getConnection("jdbc:mysql://localhost:3306/rentbicycle","root","");
    }
    catch (Exception e){
    System.out.println(e);
    }
    return con;
    }
    
    public static  Customer getCustById(String uname){
    Customer e= new  Customer();
    try{
    Connection con=ViewDao.getConnection();
    PreparedStatement ps=con.prepareStatement("select*from customer where Username=?");
    ps.setString(1,uname);
    ResultSet rs= ps.executeQuery();
    
    if(rs.next())
    {
    e.setId(rs.getInt(1));
    e.setName(rs.getString(2));
    e.setIc(rs.getString(3));
    e.setPhone_num(rs.getString(4));
    e.setAddress(rs.getString(5));
    e.setEmail(rs.getString(6));
    e.setUsername(rs.getString(7));
    e.setPassword(rs.getString(8));
    }
   
    con.close();
    } catch (Exception ex){
    ex.printStackTrace();
    }
    return e;
    }
    
    public static Staff getStaffById(String uname){
    Staff e= new  Staff();
    try{
    Connection con=ViewDao.getConnection();
    PreparedStatement ps=con.prepareStatement("select*from staff where Username=?");
    ps.setString(1,uname);
    ResultSet rs= ps.executeQuery();
    
    if(rs.next())
    {
    e.setId(rs.getInt(1));
    e.setName(rs.getString(2));
    e.setIc(rs.getString(3));
    e.setPhone_num(rs.getString(4));
    e.setAddress(rs.getString(5));
    e.setEmail(rs.getString(6));
    e.setUsername(rs.getString(7));
    e.setPassword(rs.getString(8));
    e.setPosition(rs.getString(9));
    e.setValidation(rs.getString(10));
    }
   
    con.close();
    } catch (Exception ex){
    ex.printStackTrace();
    }
    return e;
    }
    
    public static Admin getAdminById(String uname){
    Admin e= new  Admin();
    try{
    Connection con=ViewDao.getConnection();
    PreparedStatement ps=con.prepareStatement("select*from admin where Username=?");
    ps.setString(1,uname);
    ResultSet rs= ps.executeQuery();
    
    if(rs.next())
    {
    e.setId(rs.getInt(1));
    e.setName(rs.getString(2));
    e.setIc(rs.getString(3));
    e.setPhone_num(rs.getString(4));
    e.setEmail(rs.getString(5));
    e.setUsername(rs.getString(6));
    e.setPassword(rs.getString(7));
    
    }
   
    con.close();
    } catch (Exception ex){
    ex.printStackTrace();
    }
    return e;
    }
    
     public static List<Customer> getALLCust()
    {
    
    List<Customer> list =new ArrayList<Customer>();
    
    try{
    Connection con=ViewDao.getConnection();
    PreparedStatement ps=con.prepareStatement("select*from customer");
     ResultSet rs= ps.executeQuery();
     while (rs.next())
     {
     Customer e=new Customer();
      e.setId(rs.getInt(1));
      e.setName(rs.getString(2));
      e.setIc(rs.getString(3));
      e.setPhone_num(rs.getString(4));
      e.setAddress(rs.getString(5));
      e.setEmail(rs.getString(6));
      e.setUsername(rs.getString(7));
      e.setPassword(rs.getString(8));
    list.add(e);
     }
      con.close();
    } catch (Exception ex){
    ex.printStackTrace();
    }
    return list;
    }   
     
     public static List<Staff> getALLStaff()
    {
    
    List<Staff> list =new ArrayList<Staff>();
    
    try{
    Connection con=ViewDao.getConnection();
    PreparedStatement ps=con.prepareStatement("select*from Staff");
     ResultSet rs= ps.executeQuery();
     while (rs.next())
     {
     Staff e=new Staff();
      e.setId(rs.getInt(1));
      e.setName(rs.getString(2));
      e.setIc(rs.getString(3));
      e.setPhone_num(rs.getString(4));
      e.setAddress(rs.getString(5));
      e.setEmail(rs.getString(6));
      e.setUsername(rs.getString(7));
      e.setPassword(rs.getString(8));
      e.setPosition(rs.getString(9));
      e.setValidation(rs.getString(10));
    list.add(e);
     }
      con.close();
    } catch (Exception ex){
    ex.printStackTrace();
    }
    return list;
    }   
     
      public static List<Admin> getALLAdmin()
    {
    List<Admin> list =new ArrayList<Admin>();
    try{
    Connection con=ViewDao.getConnection();
    PreparedStatement ps=con.prepareStatement("select*from admin");
     ResultSet rs= ps.executeQuery();
     while (rs.next())
     {
    Admin e=new Admin();
    e.setId(rs.getInt(1));
    e.setName(rs.getString(2));
    e.setIc(rs.getString(3));
    e.setPhone_num(rs.getString(4));
    e.setEmail(rs.getString(5));
    e.setUsername(rs.getString(6));
    e.setPassword(rs.getString(7));
 
    list.add(e);
     }
      con.close();
    } catch (Exception ex){
    ex.printStackTrace();
    }
    return list;
    }   
     
}
